# Amazon JP Email Validator

This Python script validates email addresses against Amazon Seller Central Japan. It uses asynchronous processing and multiprocessing to efficiently check large lists of email addresses.

## Features

- Validates emails against Amazon Seller Central Japan
- Asynchronous HTTP requests for better performance
- Multiprocessing support for handling large email lists
- Colored console output for easy result identification
- Automatic categorization of results into LIVE, DEAD, and ERROR files

## Requirements

- Python 3.7 or higher
- Internet connection

## Dependencies

The script requires the following Python packages:

- `httpx` - Modern HTTP client for async requests
- `beautifulsoup4` - HTML parsing library
- `colorama` - Cross-platform colored terminal text
- `fake-useragent` - Generates random user agents

## Installation

1. **Clone or download this repository**

2. **Create and activate a virtual environment (recommended)**:
   
   Using Python's built-in venv module:
   ```bash
   # Create virtual environment
   python -m venv amz-validator-env
   
   # Activate virtual environment
   # On Windows:
   amz-validator-env\Scripts\activate
   
   # On macOS/Linux:
   source amz-validator-env/bin/activate
   ```

3. **Install required dependencies**:
   ```bash
   pip install httpx beautifulsoup4 colorama fake-useragent
   ```

   Alternatively, if you have a requirements.txt file:
   ```bash
   pip install -r requirements.txt
   ```

   **Note**: Using a virtual environment is strongly recommended to avoid conflicts with other Python projects and to keep your system Python clean.

## Setup

1. **Prepare your email list**:
   Create a file named `list.txt` in the same directory as `main.py`. Add one email address per line:
   ```
   email1@example.com
   email2@example.com
   email3@example.com
   ```

## Usage

Run the script using Python:

```bash
python main.py
```

### What the script does:

1. Reads email addresses from `list.txt`
2. Divides the list into chunks based on your CPU core count
3. Processes each chunk in parallel using multiprocessing
4. For each email, attempts to validate it against Amazon Seller Central Japan
5. Categorizes results and saves them to separate files

### Output Files

The script creates three output files:

- **`LIVE.txt`** - Contains emails that appear to be valid Amazon accounts
- **`DEAD.txt`** - Contains emails that don't have Amazon accounts
- **`ERROR.txt`** - Contains emails that encountered errors during validation

### Console Output

The script provides real-time colored feedback:
- 🟢 **GREEN [LIVE]** - Valid email found
- 🔴 **RED [DEAD]** - Email not found in Amazon's system
- 🟡 **YELLOW [ERROR]** - Error occurred during validation

## Configuration

### Adjusting Concurrency

You can modify the concurrency settings in the script:

- **Semaphore limit** (line 108): Controls concurrent requests per process
  ```python
  semaphore = asyncio.Semaphore(5)  # Max 5 concurrent requests per process
  ```

- **Process count** (line 121): Uses all CPU cores by default
  ```python
  num_processes = multiprocessing.cpu_count()
  ```

### Timeout Settings

HTTP timeout can be adjusted in the `AmazonValidator` class (line 33):
```python
timeout=30  # 30 seconds timeout
```

## Troubleshooting

### Common Issues

1. **Import Errors**: Make sure all dependencies are installed
   ```bash
   pip install httpx beautifulsoup4 colorama fake-useragent
   ```

2. **File Not Found**: Ensure `list.txt` exists in the same directory as `main.py`

3. **Permission Errors**: Make sure you have write permissions for output files

4. **Network Issues**: Check your internet connection and firewall settings

### Error Types

- **EmailNotFound**: The email doesn't exist in Amazon's system
- **Unknown Error**: Generic error, could be network issues or Amazon's anti-bot measures

## Performance Tips

- For very large lists (10,000+ emails), consider running in smaller batches
- The script automatically adjusts to your CPU cores for optimal performance
- Monitor your internet connection stability for best results

## Legal Notice

This tool is for educational and legitimate business purposes only. Make sure you comply with:
- Amazon's Terms of Service
- Applicable privacy laws and regulations
- Email validation best practices

## Support

If you encounter issues:
1. Check that all dependencies are properly installed
2. Verify your `list.txt` file format
3. Ensure stable internet connection
4. Check console output for specific error messages