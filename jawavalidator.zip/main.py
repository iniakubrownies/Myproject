import asyncio
import httpx
from bs4 import BeautifulSoup
import random
from colorama import Fore, init
from fake_useragent import UserAgent
import multiprocessing
import os

init(autoreset=True)

ua = UserAgent()


def get_random_desktop_useragent():
    while True:
        user_agent = ua.random
        if 'Windows' in user_agent or 'Macintosh' in user_agent or 'X11' in user_agent:
            return user_agent


class EmailNotFound(Exception):
    pass


class AmazonValidator:

    def __init__(self, email: str) -> None:
        self.email = email
        self.client = httpx.AsyncClient(
            headers={"user-agent": get_random_desktop_useragent()},
            timeout=30,
            follow_redirects=True)

    async def run(self):
        login_page_response = await self.client.get(
            "https://sellercentral.amazon.com/signin?ref_=scus_soa_wp_signin_n_c&initialSessionID=141-7316082-1953366&ld=SCUSWPDirect_SC_WP_LOGIN_N_C&pageName=US%3ASD%3ASC-WP"
        )
        login_page_html = BeautifulSoup(login_page_response.text,
                                        "html.parser")

        login_form = login_page_html.find("form", {"name": "signIn"})
        login_inputs = login_form.find_all("input")

        payload = {}
        for login_input in login_inputs:
            input_name = login_input.get("name")
            input_value = login_input.get("value")
            if input_name:
                payload[input_name] = input_value

        response = await self.client.post(
            "https://sellercentral.amazon.com/ap/signin",
            headers={
                "content-type":
                "application/x-www-form-urlencoded",
                "accept":
                "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7"
            },
            data={
                **payload, "email": self.email
            })
        response_html = BeautifulSoup(response.text, "html.parser")

        is_error = response_html.select_one('#auth-error-message-box')
        if is_error:
            error_message_element = response_html.select_one(
                '#auth-error-message-box .a-alert-content')
            if error_message_element:
                error_message = str(error_message_element.text).strip()
            else:
                error_message = "Unknown error message structure"

            if 'cannot find an account' in error_message:
                raise EmailNotFound(error_message)

            raise Exception(f"Unknown Error: {error_message}")

        has_input_password = response_html.select_one("#ap_password")
        if has_input_password:
            return self.email

        raise Exception("Unknown Error")

    async def close(self):
        await self.client.aclose()


async def validate_email(email: str, output_dir: str, semaphore: asyncio.Semaphore):
    async with semaphore:
        validator = AmazonValidator(email)
        try:
            await validator.run()
            print(f"{Fore.GREEN}[LIVE]: {email}")
            result = f"{email}"
            try:
                os.makedirs(output_dir, exist_ok=True)
            except Exception as e:
                print(f"{Fore.YELLOW}[ERROR]: Failed to create output directory: {e}")
                return
            live_file_path = os.path.join(output_dir, "LIVE.txt")
            with open(live_file_path, "a") as f:
                f.write(result + "\n")
        except EmailNotFound as e:
            print(f"{Fore.RED}[DEAD]: {email} - {e}")
            result = f"{email}"
            try:
                os.makedirs(output_dir, exist_ok=True)
            except Exception as e:
                print(f"{Fore.YELLOW}[ERROR]: Failed to create output directory: {e}")
                return
            dead_file_path = os.path.join(output_dir, "DEAD.txt")
            with open(dead_file_path, "a") as f:
                f.write(result + "\n")
        except Exception as e:
            print(f"{Fore.YELLOW}[ERROR]: {email} - {e}")
            result = f"{email}"
            try:
                os.makedirs(output_dir, exist_ok=True)
            except Exception as e:
                print(f"{Fore.YELLOW}[ERROR]: Failed to create output directory: {e}")
                return
            error_file_path = os.path.join(output_dir, "ERROR.txt")
            with open(error_file_path, "a") as f:
                f.write(result + "\n")
        finally:
            await validator.close()


async def process_chunk(chunk: list, output_dir: str, max_threads: int):
    semaphore = asyncio.Semaphore(max_threads)
    await asyncio.gather(
        *[validate_email(email, output_dir, semaphore) for email in chunk])


def worker(chunk: list, output_dir: str, max_threads: int):
    asyncio.run(process_chunk(chunk, output_dir, max_threads))


def main():
    try:
        list_file_path = input("Enter the file path to 'list.txt': ")
        output_dir = input("Enter the directory to save output files: ")
        try:
            max_threads_input = input("Enter the number of concurrent threads (default 5): ")
            max_threads = int(max_threads_input) if max_threads_input.strip() else 5
        except ValueError:
            print(f"{Fore.YELLOW}[WARNING]: Invalid input for threads, using default value of 5")
            max_threads = 5
        with open(list_file_path, 'r') as f:
            emails = f.read().splitlines()
            emails = [email.strip() for email in emails]
    except Exception as e:
        print(f"{Fore.RED}[ERROR]: Failed to read input files: {e}")
        return

    num_processes = multiprocessing.cpu_count()

    chunk_size = max(1, len(emails) // num_processes)
    chunks = [
        emails[i:i + chunk_size] for i in range(0, len(emails), chunk_size)
    ]

    processes = []
    for chunk in chunks:
        p = multiprocessing.Process(target=worker, args=(chunk, output_dir, max_threads))
        processes.append(p)
        p.start()

    for p in processes:
        p.join()


if __name__ == '__main__':
    multiprocessing.freeze_support()
    main()
