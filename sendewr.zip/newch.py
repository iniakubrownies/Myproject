import smtplib
import string
import random
import re
import threading
import queue
from email.mime.text import MIMEText
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime

# =========================
# CONFIG
# =========================
THREADS = 15  # Naikkan thread jika koneksi stabil
# Delay dihapus total untuk kecepatan penuh

# Antrean untuk menampung target pengiriman
task_queue = queue.Queue()
lock = threading.Lock()

# =========================
# RANDOM DEVICE & BROWSER
# =========================

DEVICES = [
    "iPhone 15 Pro",
    "iPhone 14",
    "Samsung Galaxy S24",
    "Samsung Galaxy S23",
    "Google Pixel 8",
    "iPad Pro",
]

BROWSERS = [
    "Chrome",
    "Mozilla Firefox",
    "Safari",
    "Brave Browser",
]

# =========================
# RANDOM COUNTRY
# =========================

COUNTRIES = [
    "United States",
    "Canada",
    "United Kingdom",
    "Germany",
    "France",
    "Netherlands",
    "Australia",
    "Singapore",
    "Japan",
    "South Korea",
    "Brazil",
    "Mexico",
    "Italy",
    "Spain",
    "Sweden",
    "Norway",
    "Indonesia",
    "Malaysia",
    "Thailand",
    "India",
]



def generate_random(length=8):
    return ''.join(random.choice(string.ascii_letters) for _ in range(length))

def generate_random_num(length=6):
    return ''.join(random.choice(string.digits) for _ in range(length))

def replace_placeholders(text, recipient=""):
    # {random} atau {random:10}
    def repl_text(match):
        length = int(match.group(1)) if match.group(1) else 8
        return generate_random(length)

    # {random_num} atau {random_num:5}
    def repl_num(match):
        length = int(match.group(1)) if match.group(1) else 6
        return generate_random_num(length)

    # {date}
    def repl_date(match):
        return datetime.now().strftime("%B %d, %Y")

    text = re.sub(r"\{random(?::(\d+))?\}", repl_text, text)
    text = re.sub(r"\{random_num(?::(\d+))?\}", repl_num, text)
    text = re.sub(r"\{date\}", repl_date, text)

    # {email}
    text = text.replace("{email}", recipient)

    # {device}
    text = text.replace("{device}", random.choice(DEVICES))

    # {browser}
    text = text.replace("{browser}", random.choice(BROWSERS))

    # {country}
    text = text.replace("{country}", random.choice(COUNTRIES))

    return text
    
def worker():
    while not task_queue.empty():
        try:
            smtp_data, recipient, body, fromnames, task_id, total_tasks = task_queue.get()
            
            host, port, user, pw, from_email = smtp_data
            
            # Proses semua placeholder di Subject, FromName, dan Body
            final_fromname = replace_placeholders(random.choice(fromnames))
            final_from_email = replace_placeholders(from_email)
            final_body = replace_placeholders(body, recipient)
            final_subject = replace_placeholders("Subscription Team renewal unsuccessful: update your billing details today")

            msg = MIMEText(final_body, "html", "utf-8")
            msg["From"] = f"{final_fromname} <{final_from_email}>"
            msg["To"] = recipient
            msg["Subject"] = final_subject

            with smtplib.SMTP(host, int(port), timeout=10) as server:
                server.ehlo()
                try: server.starttls()
                except: pass
                server.login(user, pw)
                server.sendmail(final_from_email, [recipient], msg.as_string())
            
            print(f"[{task_id}/{total_tasks}] ✅ SENT: {recipient}")
            
        except Exception as e:
            print(f"❌ FAILED: {recipient} | {str(e)[:50]}")
        finally:
            task_queue.task_done()

if __name__ == "__main__":
    # 1. Load semua data (logika load dari newch.py)[cite: 1]
    with open("email.txt", "r") as f:
        emails = [l.strip() for l in f if l.strip()]
    with open("letter.html", "r") as f:
        body = f.read()
    with open("fromname.txt", "r") as f:
        fromnames = [l.strip() for l in f if l.strip()]
    with open("smtps.txt", "r") as f:
        smtp_list = []
        for line in f:
            p = line.strip().split("|")
            if len(p) == 5: smtp_list.append(p)
            elif len(p) == 3: smtp_list.append([p[0], 587, p[1], p[2], p[1]])

    # 2. Masukkan semua kombinasi ke antrean (Queue)
    # Ini jauh lebih cepat karena SMTP digunakan secara bergantian[cite: 1]
    total_tasks = len(emails)
    for i, target in enumerate(emails, 1):
        # Gunakan SMTP secara berputar (round-robin)
        current_smtp = smtp_list[i % len(smtp_list)]
        task_queue.put((current_smtp, target, body, fromnames, i, total_tasks))

    print(f"🚀 Memulai pengiriman dengan {THREADS} thread...")
    
    # 3. Jalankan ThreadPool
    with ThreadPoolExecutor(max_workers=THREADS) as executor:
        for _ in range(THREADS):
            executor.submit(worker)

    print("✅ SELESAI!")